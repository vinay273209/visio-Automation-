#include "arduino_secrets.h"

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>

// ===== FAN PINS (ESP32 GPIO) =====
#define FAN1 23
#define FAN2 22
#define FAN3 19
#define FAN4 18

// ===== WIFI =====
const char* ssid = "iPhone";
const char* password = "11234567";

// ===== MQTT (EMQX) =====
const char* mqtt_server = "z9262f1f.ala.eu-central-1.emqxsl.com";
const int mqtt_port = 8883;
const char* mqtt_user = "NIET_273209";
const char* mqtt_pass = "Yaniv@273209";

WiFiClientSecure espClient;
PubSubClient client(espClient);

// ===== FAN STATES =====
bool fan1State = false;
bool fan2State = false;
bool fan3State = false;
bool fan4State = false;

// ===== MQTT CALLBACK =====
void callback(char* topic, byte* payload, unsigned int length) {

  String message = "";

  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  String t = String(topic);

  Serial.print("MQTT RECEIVED -> ");
  Serial.print(t);
  Serial.print(" : ");
  Serial.println(message);

  // ===== FAN1 =====
  if (t == "home/fan1/set") {

    if (message == "ON" && fan1State == false) {
      digitalWrite(FAN1, LOW);
      fan1State = true;
      Serial.println("Fan1 ON");
    }

    else if (message == "OFF" && fan1State == true) {
      digitalWrite(FAN1, HIGH);
      fan1State = false;
      Serial.println("Fan1 OFF");
    }

    else {
      Serial.println("Fan1 command ignored");
    }
  }

  // ===== FAN2 =====
  if (t == "home/fan2/set") {

    if (message == "ON" && fan2State == false) {
      digitalWrite(FAN2, LOW);
      fan2State = true;
      Serial.println("Fan2 ON");
    }

    else if (message == "OFF" && fan2State == true) {
      digitalWrite(FAN2, HIGH);
      fan2State = false;
      Serial.println("Fan2 OFF");
    }

    else {
      Serial.println("Fan2 command ignored");
    }
  }

  // ===== FAN3 =====
  if (t == "home/fan3/set") {

    if (message == "ON" && fan3State == false) {
      digitalWrite(FAN3, LOW);
      fan3State = true;
      Serial.println("Fan3 ON");
    }

    else if (message == "OFF" && fan3State == true) {
      digitalWrite(FAN3, HIGH);
      fan3State = false;
      Serial.println("Fan3 OFF");
    }

    else {
      Serial.println("Fan3 command ignored");
    }
  }

  // ===== FAN4 =====
  if (t == "home/fan4/set") {

    if (message == "ON" && fan4State == false) {
      digitalWrite(FAN4, LOW);
      fan4State = true;
      Serial.println("Fan4 ON");
    }

    else if (message == "OFF" && fan4State == true) {
      digitalWrite(FAN4, HIGH);
      fan4State = false;
      Serial.println("Fan4 OFF");
    }

    else {
      Serial.println("Fan4 command ignored");
    }
  }
}

// ===== MQTT RECONNECT =====
void reconnect() {

  while (!client.connected()) {

    Serial.print("Connecting to MQTT...");

    if (client.connect("ESP32_Device_01", mqtt_user, mqtt_pass)) {

      Serial.println("CONNECTED");

      client.subscribe("home/fan1/set");
      client.subscribe("home/fan2/set");
      client.subscribe("home/fan3/set");
      client.subscribe("home/fan4/set");

    } else {

      Serial.print("FAILED rc=");
      Serial.print(client.state());
      Serial.println(" retry in 3 seconds");

      delay(3000);
    }
  }
}

// ===== WIFI CONNECT =====
void connectWiFi() {

  Serial.println("Connecting WiFi...");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

// ===== SETUP =====
void setup() {

  Serial.begin(115200);
  delay(1000);

  Serial.println("ESP32 STARTING");

  pinMode(FAN1, OUTPUT);
  pinMode(FAN2, OUTPUT);
  pinMode(FAN3, OUTPUT);
  pinMode(FAN4, OUTPUT);

  digitalWrite(FAN1, HIGH);
  digitalWrite(FAN2, HIGH);
  digitalWrite(FAN3, HIGH);
  digitalWrite(FAN4, HIGH);

  connectWiFi();

  espClient.setInsecure();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

// ===== LOOP =====
void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}